/*
 * Description: implementation of object.hpp
 * Author: HBF
 * Version: 2021-08-24
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "object.hpp"

void insert(LIST *list, SHAPE *object) {
	if(object == NULL)
		return;

	NODE *p = (NODE*) malloc(sizeof(NODE));
		p->object = object;
		p->prev = NULL;
		p->next = NULL;

		if(list->start == NULL){
			list->start = p;
			list->end = p;
		} else {
			list->end->next = p;
			p->prev = list->end;
			list->end = p;
		}
}

void deleteNode(LIST *list, NODE **selectp) {
	NODE *select = *selectp;
	if(select == NULL)
		return;

	NODE *p = NULL;
	if (select == list->start && select == list->end){
		list->start = NULL;
		list->end - NULL;
	} else if (select == list->start){
		p = select->next;
		p->prev = NULL;
		list->start = p;
	} else if (select == list->end) {
		p = list->end->prev;
		p->next = NULL;
		list->end = p;
	} else {
		p = select->prev;
		p->next = select->next;
		p->prev = select->prev;
	}
	free(select->object);
	free(select);

}

void clearList(LIST *list) {
	NODE *p = list->start;
	NODE *temp = NULL;
	while(p) {
		temp = p->next;
		free(p->object);
		free(p);
		p = temp;
	}
	list->start = NULL;
	list->end = NULL;
}

void drawShape(SHAPE *object) {
	if (object->type == RECTANGLE) {  // rectangle
		glColor3f(object->fr, object->fg, object->fb);
		glBegin(GL_QUADS);
		glVertex2i(object->x1, object->y1);
		glVertex2i(object->x1, object->y2);
		glVertex2i(object->x2, object->y2);
		glVertex2i(object->x2, object->y1);
		glEnd();

		glColor3f(object->sr, object->sg, object->sb);
		glLineWidth(object->swidth);
		glBegin(GL_LINE_LOOP);
		glVertex2i(object->x1, object->y1);
		glVertex2i(object->x1, object->y2);
		glVertex2i(object->x2, object->y2);
		glVertex2i(object->x2, object->y1);
		glEnd();

	} else if (object->type == CIRCLE) {  // circle
		glColor3f(object->fr, object->fg, object->fb);
		circleMidpointFill(object->x1, object->y1, object->x2, object->y2);
		glColor3f(object->sr, object->sg, object->sb);
		circleMidpoint(object->x1, object->y1, object->x2, object->y2);
	}
}

void drawShapeHighLight(SHAPE *object) {
	if (object == NULL)
		return;

	if(object->type == RECTANGLE){
		glColor3f(1.0,1.0,0);
		glLineWidth(object->swidth);
		glBegin(GL_LINE_LOOP);
		glVertex2i(object->x1, object->y1);
		glVertex2i(object->x1, object->y2);
		glVertex2i(object->x2, object->y2);
		glVertex2i(object->x2, object->y1);
		glEnd();
	} else if (object->type == CIRCLE) {
		glColor3f(1.0,1.0,0);
		circleMidpoint(object->x1, object->y1, object->x2, object->y2);
	}
}

void drawList(LIST *list) {
	NODE *p = list->start;
	while (p) {
		drawShape(p->object);
		p = p->next;
	}
}

void setPixel(GLint x, GLint y) {
	glPointSize(2.0);
	glBegin(GL_POINTS);
	glVertex2i(x, y);
	glEnd();
}

// draw points on line of circle
void circlePlotPoints(const GLint& xc, const GLint& yc, const GLint& x,
		const GLint& y) {
	setPixel(xc + x, yc + y);
	setPixel(xc - x, yc + y);
	setPixel(xc + x, yc - y);
	setPixel(xc - x, yc - y);
	setPixel(xc + y, yc + x);
	setPixel(xc - y, yc + x);
	setPixel(xc + y, yc - x);
	setPixel(xc - y, yc - x);
}

// draw circle main function
void circleMidpoint(GLint x1, GLint y1, GLint x2, GLint y2) {
	GLint r;
	r = (GLint) sqrt((x2-x1) * (x2-x1) + (y2-y1) * (y2-y1));
	GLint p = 1 - r;
	GLint x=0, y=r;
	circlePlotPoints(x1,y1,x,y);
	while(x < y) {
		x++;
		if (p < 0){
			p += 2 * x + 1;
		} else {
			y--;
			p += 2 * (x - y) + 1;
		}
		circlePlotPoints(x1,y1,x,y);
	}
}

void circlePlotPointsFill(GLint x1, GLint y1, GLint x, GLint y) {
	glLineWidth(2.0);
	glBegin(GL_LINES);
	glVertex2i(x1 - x, y1 + y);
	glVertex2i(x1 + x, y1 + y);
	glVertex2i(x1 - x, y1 - y);
	glVertex2i(x1 + x, y1 - y);
	glVertex2i(x1 - y, y1 + x);
	glVertex2i(x1 + y, y1 + x);
	glVertex2i(x1 - y, y1 - x);
	glVertex2i(x1 + y, y1 - x);
	glEnd();
}

void circleMidpointFill(GLint x1, GLint y1, GLint x2, GLint y2) {
	GLint radious;
	radious = (GLint) sqrt((x2-x1) * (x2-x1) + (y2-y1) * (y2-y1));
	GLint p = 1 - radious;
	GLint x = 0;
	GLint y = radious;

	circlePlotPointsFill(x1,y1,x,y);

	while(x < y) {
			x++;
			if (p < 0){
				p += 2 * x + 1;
			} else {
				y--;
				p += 2 * (x - y) + 1;
			}
			circlePlotPointsFill(x1,y1,x,y);
		}
}
