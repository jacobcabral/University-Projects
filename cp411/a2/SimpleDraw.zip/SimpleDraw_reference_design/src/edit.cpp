/*
 * Description: implementation of edit.hpp
 * Author: HBF
 * Version: 2021-08-24
 */

#include <stdio.h>
#include <GL/glut.h>
#include <math.h>
#include "object.hpp"

extern LIST objlist;

GLint min(GLint x, GLint y) {
	return x < y ? x : y;
}

GLint max(GLint x, GLint y) {
	if (x < y)
		return y;
	else
		return x;
}

NODE *select(GLint x, GLint y) {
	NODE *p = objlist.end;
	while (p){
		printf("check (x1,y1):%d, %d\n",p->object->x1, p->object->y1);

		if(p->object->type == 1 && min(p->object->x1, p->object->x2) < x
				&& max(p->object->x1, p->object->x2) > x
				&& min(p->object->y1, p->object->y2) < y
				&& max(p->object->y1, p->object->y2) > y) {
			break;
		} else if (p->object->type == 2){
			GLint radious = (GLint) (p->object->x2 - p->object->x1) * (p->object->x2 - p->object->x1) + (p->object->y2 - p->object->y1) * (p->object->y2 - p->object->y1);
			if((x-p->object->x1) * (x-p->object->x1) + (y-p->object->y1) * (y-p->object->y1) < radious) {
				break;
			}
		}
		p = p->prev;

	}

	return NULL;
}

void Delete(NODE **pp) {
//	deleteNode(objlist, *pp);
}

void moveFront(NODE *p) {
	// your implementation
}

void moveBack(NODE *p) {
	// your implementation
}

