/*
 *  SimpleView : reference design
 *  Author: HBF
 *  Version: 2021-10-06
 */
#ifndef PYRAMID_HPP_
#define PYRAMID_HPP_

#include <GL/glut.h>
#include "Shape.hpp"
#include "Vector.hpp"
#include "Camera.hpp"
#include "Light.hpp"


class Pyramid: public Shape {
protected:
	GLfloat vertex[5][3];
	GLint face[4][4];

	/* SimpleView2 properties */
	GLfloat faceColor[4][3];
	GLfloat faceNormal[4][3];
	GLfloat vertexColor[5][3];
	GLfloat vertexNormal[5][3];

	GLfloat r, g, b;
public:
	Pyramid();
	void draw();
	void drawMC();
	void drawFace(int i);


	/* SimpleView2 properties */
	bool isFrontface(int faceindex, Camera camera);
	GLfloat getFaceShade(int faceindex, Light light);
	GLfloat getVertexShade(int vertexindex, Light light);
};


#endif  /* PYRAMID_HPP_ */

