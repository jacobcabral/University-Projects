## SimpleView Reference Design

Author: HBF

Date: 2021-10-06

## What's about

This is a reference design to A2Q3 SimpleView program. You are allowed to design and implement your SimpleView program based on this reference design. 


## Working plan


1. Try the provided execugtable sample program, to see what your SimpleView should look like at runtime. Import the SimpleView_reference_design.zip into Eclipse to as existing archive project. Understand the program design by reading the SimpleView.cpp, *.hpp and *.cpp files.  
2. Create your SimpleView project with the similar files like the reference design. Add menu to the your program, so that your SimpleView program has the menu structure like the sample program. 

3. Work on Cube class, setting vertices and faces, drawFace(int i) and draw() functions, to draw the cube. 

4. Implement Matrix functions. 

matrixPreMultiply(Matrix* m);  	// mat <- m*mat
void transpose();  				// mat <- mat'
void multiplyVector(GLfloat* v); // mat*v
void rotateMatrix(GLfloat x, GLfloat y, GLfloat z, GLfloat angle); //mat <- Rotation(rx, ry, rz, angle)

5. Implement 

void Shape::rotateMCS(GLfloat rx, GLfloat ry, GLfloat rz, GLfloat angle)  to rotate the cube in MCS. 

void Shape::rotateOrigin(GLfloat rx, GLfloat ry, GLfloat rz, GLfloat angle) to rotate the origion of MCS 
in WCS. As a result, the cube can rotate w.r.t WCS y - axis

void Camera::rotate(GLfloat rx, GLfloat ry, GLfloat rz, GLfloat angle) rotate eye position.

void Camera::translate(GLfloat tx, GLfloat ty, GLfloat tz) 


6. Create Pyramid class and add Pyramid object to World, similar to Cube class. 

	obj = new Pyramid();
	obj->translate(-2.5, 0, 0);
	objlist.push_back(obj);


7. Create House class, by objects Pyramid* pyramid and Cube* cube; and use
pyramid->translate(0, 2, 0) to put pyramid at the top of the cube.

	obj = new House();
	obj->setId(3);
	obj->translate(2.5, 0, 0);
	objlist.push_back(obj);



