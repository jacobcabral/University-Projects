/*
 * House.cpp
 *
 *  Created on: Oct 26, 2021
 *      Author: Jake
 */


#include "World.hpp"
#include "House.hpp"
#include "Cube.hpp"
#include "Pyramid.hpp"

House::House()
{

    cube = new Cube();
    pyramid = new Pyramid();
    pyramid->translate(0, 0, 2);

    r = 1.0;
    g = 0.0;
    b = 1.0;
}

void House::draw()
{
    glPushMatrix();
    this->ctmMultiply();
 // set color
 // draw all faces
    glColor3f(r,g,b);
    glPointSize(1);
    glLineWidth(1);
    glScalef(s,s,s);

    cube->draw();
    glPopMatrix();

    glPushMatrix();
    this->ctmMultiply();
 // set color
 // draw all faces

    glColor3f(r,g,b);         // color.
    glPointSize(1);                    // Shape Thickness
    glLineWidth(1);                      // Stroke Width.
    glScalef(s,s,s);

    //Draw triangle sides
    pyramid->draw();

    glPopMatrix();

}
