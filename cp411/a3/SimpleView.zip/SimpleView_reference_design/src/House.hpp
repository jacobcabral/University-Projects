/*
 * House.hpp
 *
 *  Created on: Oct 26, 2021
 *      Author: Jake
 */

#ifndef HHOUSE_H
#define HHOUSE_H

#include <GL/glut.h>
#include "Shape.hpp"
#include "Vector.hpp"

class House: public Shape {
protected:
    GLfloat vertex[9][3];
    GLint face[9][4];
    GLfloat r, g, b;
public:
    Shape *cube;
    Shape *pyramid;
    House();
    void draw();
    void drawFace(int);
};
#endif
