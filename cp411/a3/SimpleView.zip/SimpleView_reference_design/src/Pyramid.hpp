/*
 * Pyramid.hpp
 *
 *  Created on: Oct 25, 2021
 *      Author: Jake
 */

#ifndef SRC_PYRAMID_HPP_
#define SRC_PYRAMID_HPP_


#include <GL/glut.h>
#include "Shape.hpp"
#include "Vector.hpp"

class Pyramid: public Shape {
protected:
	GLfloat vertex[5][3];  /* 2D array to store cube vertices */
	GLint face[6][3];      /* 2D array to store faces */
	GLfloat r, g, b;       /* color pyramid */
public:
	Pyramid();
	void draw();
	void drawFace(int);
};



#endif /* SRC_PYRAMID_HPP_ */
