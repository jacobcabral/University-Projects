/*
 * Description: SimpleView reference design
 * Author: HBF
 * Version: 2021-10-06
 */
#ifndef CSHAPE_H
#define CSHAPE_H

#include <GL/glut.h>
#include <stdlib.h>
#include <iostream>
#include <math.h>
#include "Matrix.hpp"

using namespace std;

/**
 * Shape
 * The common class that will be inherited by model object class
 */
class Shape {
protected:
	Matrix mc;  /* the Model coordinate system (X, Y, Z, 0) in WC, represent the position of the object in WC */
	GLfloat s;  /* scale factor */
	GLint id;   /* used to identify object */

public:
	Shape();                 /* constructor */
	virtual ~Shape();        /* destructor  */
	Matrix getMC();          /* return Matrix object */
	void ctmMultiply();      /* function to do the CTM * MC */
	void setScale (GLfloat x); /* set scale factor */
	void scaleChange (GLfloat x); /* set scale factor */
	void setId(GLint id);
	GLint getId();
	void translate(GLfloat tx, GLfloat ty, GLfloat tz); /* translate the MC origin by (tx, ty, tz) */
	void rotate(GLfloat rx, GLfloat ry, GLfloat rz, GLfloat angle);   /* rotate object in WC */
	void rotateOrigin(GLfloat x0, GLfloat  y0, GLfloat  z0, GLfloat  rx, GLfloat  ry, GLfloat rz,  GLfloat  angle); /* just rotate the origin of object in WC */
	void rotateMCS(GLfloat rx, GLfloat ry, GLfloat rz, GLfloat angle);    /* to rotate in MC */
	void reset();             /* a function that resets the shape transformation matrix */
	virtual void draw() = 0;  /* draw function must be overwritten */
};

#endif
