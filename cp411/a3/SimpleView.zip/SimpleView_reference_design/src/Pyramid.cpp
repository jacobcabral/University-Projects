/*
 * Pyramid.cpp
 *
 *  Created on: Oct 25, 2021
 *      Author: Jake
 */
#include "Pyramid.hpp"

Pyramid::Pyramid(){

	vertex[0][0] = 0;
	vertex[0][1] = 0;
	vertex[0][2] = 0;

	vertex[1][0] = 1.0;
	vertex[1][1] = 0;
	vertex[1][2] = 0;

	vertex[2][0] = 1.0;
	vertex[2][1] = 1.0;
	vertex[2][2] = 0;

	vertex[3][0] = 0;
	vertex[3][1] = 1.0;
	vertex[3][2] = 0;

	vertex[4][0] = 0.5;
	vertex[4][1] = 0.5;
	vertex[4][2] = 1.0;

	 face[0][0] = 0;
	 face[0][1] = 1;
	 face[0][2] = 3;

	 face[1][0] = 3;
	 face[1][1] = 2;
	 face[1][2] = 1;


	 face[2][0] = 4;
	 face[2][1] = 0;
	 face[2][2] = 1;


	 face[3][0] = 4;
	 face[3][1] = 0;
	 face[3][2] = 3;


	 face[4][0] = 4;
	 face[4][1] = 1;
	 face[4][2] = 2;


	 face[5][0] = 3;
	 face[5][1] = 2;
	 face[5][2] = 4;

	 r = 1.0;
	 g = 1.0;
	 b = 0;
}

void Pyramid::drawFace(int i){
		glBegin(GL_LINE_LOOP);
		glVertex3fv(vertex[face[i][0]]);
		glVertex3fv(vertex[face[i][1]]);
		glVertex3fv(vertex[face[i][2]]);
		glEnd();
}

void Pyramid::draw(){
		glPushMatrix();
	    this->ctmMultiply();
	    glScalef(s,s,s);
	    glColor3f( r, g, b);
	    for (int i =0 ; i<6; i++)
	    	drawFace(i);
	    glPopMatrix();
}
