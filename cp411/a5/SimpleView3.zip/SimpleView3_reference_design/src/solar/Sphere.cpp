#include "Sphere.hpp"

extern RenderMode renderMode;

Sphere::Sphere(GLdouble size) {
	radius = size;
	splices = 50;
	stacks = 50;
	textureID = 0;
	r=1;
	g=1;
	b=1;
	quad = gluNewQuadric();
}

void Sphere::draw() {
	glPushMatrix();
	ctmMultiply();

	switch (renderMode) {
		case WIRE:
		case CONSTANT:
		case FLAT:
		case SMOOTH:
			glColor3f(r, g, b);
			glutSolidSphere(radius,splices,stacks);
			break;

		case TEXTURE:
			gluQuadricDrawStyle(quad, GLU_FILL);
			gluQuadricTexture(quad, GL_TRUE);
			gluQuadricNormals(quad, GLU_SMOOTH);
			glShadeModel(GL_FLAT);
			glEnable(GL_TEXTURE_2D);
			glRotatef(0, 0.0, 1.0, 0.0);
			glBindTexture(GL_TEXTURE_2D, textureID);
			glRotatef(0, 1.0, 0.0, 1.0);
			gluSphere(quad, radius, splices, stacks);
			glDisable(GL_TEXTURE_2D);
			glPopMatrix();
			 break;

		case PHONE:
			glPolygonMode( GL_FRONT, GL_FILL);
			        glPolygonMode( GL_BACK, GL_LINE);
			        // your code to draw filled mesh, using GL_QUAD_STRIP
			        for (int i=0; i<row-1; i++) {
			                glBegin( GL_QUAD_STRIP);
			                for (int j=0; j<col; j++) {
			                    glNormal3f(Normal[i][j].x,Normal[i][j].y,Normal[i][j].z);
			                    glVertex3f(Pts[i][j].x, Pts[i][j].y, Pts[i][j].z);
			                    glNormal3f(Normal[i+1][j].x,Normal[i+1][j].y,Normal[i+1][j].z);
			                    glVertex3f(Pts[i+1][j].x, Pts[i+1][j].y, Pts[i+1][j].z);
			                }
			                glEnd();
			            }
			break;
	}

	glPopMatrix();
}


